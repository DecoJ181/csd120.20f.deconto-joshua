import turtle

t = turtle.Turtle ()
t.right (45)
    
for i in range (4):
    t.left (90)
    t.forward (50)
    t.right (90)
    t.forward (50)

t.right (90)

for i in range (4):
    t.forward (50)
    t.right (90)
    t.forward (50)
    t.left (90)

t.left (135)

turtle.done ()
