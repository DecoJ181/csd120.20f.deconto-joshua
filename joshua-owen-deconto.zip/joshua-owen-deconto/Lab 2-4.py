import turtle
t = turtle.Turtle ()

diamonds = 7
line_length = 30
angle = 18

def diamond_chain (d,l,a):
    #! Incomplete docsring
    """ diamond_chain accepts 1 argument greater than 0
    """
    t.right (a)
    draw_top (d,l,a);
    t.right (180-2*a)
    draw_bottom (d,l,a);
    t.left (180-a)
    """ program will draw the specified number of diamonds provided to the function
    """
    return ()

def draw_top (d,l,a):
    for i in range (d):
        t.left (2*a)
        t.forward (l)
        t.right (2*a)
        t.forward (l)
    return

def draw_bottom (d,l,a):
    for i in range (d):
        t.forward (l)
        t.right (2*a)
        t.forward (l)
        t.left (2*a)
    return

diamond_chain (diamonds, line_length, angle);

turtle.done ();
