import turtle
t = turtle.Turtle ()
t.speed (10)

grid_size = 6
spacing = 60

def flower1 (t):
    diamonds = 3
    line_length = 9
    angle = 53
    petals = 5
    #! As per lab instructions, you could use keyword arguments here instead to avoid the need for all the variables:
    #! diamond_flower(d=3, l=9, a=53, p=5)
    #! (which reveals that perhaps your parameters could have clearer names)
    diamond_flower (diamonds,line_length,angle,petals);
    return

def flower2 (t):
    diamonds = 3
    line_length = 30
    angle = 20
    petals = 5
    diamond_flower (diamonds,line_length,angle,petals);
    return

def flower3 (t):
    diamonds = 7
    line_length = 32
    angle = 40
    petals = 8
    diamond_flower (diamonds,line_length,angle,petals);
    #! Return not required here. Functions always return at the end of their bodies
    return

#! THIS is the parameterization I was looking for in 2-5.  Glad you found it here.
def diamond_flower (d,l,a,p):
    for i in range (p):
        diamond_chain (d, l, a);
        t.left (360/p)
    return

def diamond_chain (r,l,a):
    """ diamond_chain accepts 1 integer argument greater than 0
    """
    t.right (a)
    draw_top (r,l,a);
    t.right (180-2*a)
    draw_bottom (r,l,a);
    t.left (180-a)
    """ program will draw the specified number of diamonds provided to the function
    """
    return ()

def draw_top (r,l,a):
    for i in range (r):
        t.left (2*a)
        t.forward (l)
        t.right (2*a)
        t.forward (l)
    return

def draw_bottom (r,l,a):
    for i in range (r):
        t.forward (l)
        t.right (2*a)
        t.forward (l)
        t.left (2*a)
    return

def stamp_grid (t,gs,s):
    #! Missing docstring
    for i in range (gs):
        for j in range (gs):
            flower1 (t);
            t.penup ()
            t.forward (s)
            t.pendown ()
        t.penup ()
        t.back (gs*s)
        t.right (90)
        t.forward (s)
        t.left (90)
        t.pendown ()
    t.penup ()
    t.left (90)
    t.forward (gs*s)
    t.right (90)
    t.pendown ()
    return

#! This isn't quite what I was looking for re stamp_func.  See the sample solution
def stamp_func ():
    stamp_grid (t,grid_size,spacing);
    return

stamp_func ();

turtle.done ();

