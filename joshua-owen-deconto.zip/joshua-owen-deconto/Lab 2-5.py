import turtle
t = turtle.Turtle ()

#! This makes a cool flower!  Nice find
diamonds = 4
line_length = 28
angle = 70
petals = 9

def diamond_flower (p):
    #! Missing docstring
    for i in range (p):
        #! This function is using the 'global' line_length and angle variables, but it should
        #! bet getting these values as parameters
        diamond_chain (diamonds, line_length, angle);
        t.left (360/p)
    return

def diamond_chain (r,l,a):
    """ diamond_chain accepts 1 argument greater than 0
    """
    t.right (a)
    draw_top (r,l,a);
    t.right (180-2*a)
    draw_bottom (r,l,a);
    t.left (180-a)
    """ program will draw the specified number of diamonds provided to the function
    """
    return ()

def draw_top (r,l,a):
    for i in range (r):
        t.left (2*a)
        t.forward (l)
        t.right (2*a)
        t.forward (l)
    return

def draw_bottom (r,l,a):
    for i in range (r):
        t.forward (l)
        t.right (2*a)
        t.forward (l)
        t.left (2*a)
    return

diamond_flower (petals);

turtle.done ();
