import turtle
t = turtle.Turtle ()

#! Your functions don't have a turtle parameter
def diamond_chain (n):
    """ diamond_chain accepts 1 integer argument greater than 0
    """
    t.right (45)
    draw_top (n);  #! Semi-colons are not necessary in Python (although they are acceptable syntax)
    t.right (90)
    draw_bottom (n);
    t.left (135)
    #! Use comments to document function-body lines of code; docstrings should only appear at the beginning of a function
    """ program will draw the specified number of diamonds provided to the function
    """
    return ()

def draw_top (n):
    for i in range (n):
        t.left (90)
        t.forward (50)
        t.right (90)
        t.forward (50)
    return

def draw_bottom (n):
    for i in range (n):
        t.forward (50)
        t.right (90)
        t.forward (50)
        t.left (90)
    return

diamond_chain (3);

diamond_chain (7);

turtle.done ();
